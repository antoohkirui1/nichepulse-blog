import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata = {
  title: "Privacy Policy — NichePulse",
  description: "NichePulse privacy policy and data handling practices.",
};

export default function PrivacyPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen">
        <div className="max-w-3xl mx-auto px-4 py-16">
          <h1 className="text-4xl font-extrabold text-gray-900 mb-8">
            Privacy Policy
          </h1>
          <div className="prose max-w-none">
            <p>
              <strong>Last updated:</strong> January 2025
            </p>

            <h2>Information We Collect</h2>
            <p>
              We collect information you provide directly (name, email when
              subscribing to our newsletter or contacting us) and information
              collected automatically (page views, browser type, device
              information via cookies and analytics).
            </p>

            <h2>How We Use Your Information</h2>
            <ul>
              <li>To send newsletters and updates you&apos;ve subscribed to</li>
              <li>To respond to your inquiries and support requests</li>
              <li>To improve our website and content</li>
              <li>To analyze traffic and usage patterns</li>
            </ul>

            <h2>Cookies</h2>
            <p>
              We use cookies to enhance your experience, analyze site traffic,
              and serve relevant advertisements. You can control cookies through
              your browser settings.
            </p>

            <h2>Third-Party Services</h2>
            <p>We use third-party services including:</p>
            <ul>
              <li>Analytics (page view tracking)</li>
              <li>Email marketing (newsletter delivery)</li>
              <li>Advertising networks (display ads)</li>
              <li>Affiliate networks (link tracking)</li>
            </ul>

            <h2>Data Security</h2>
            <p>
              We implement reasonable security measures to protect your personal
              information. However, no method of transmission over the Internet
              is 100% secure.
            </p>

            <h2>Your Rights</h2>
            <p>
              You can unsubscribe from our newsletter at any time by clicking the
              unsubscribe link in any email. You can request deletion of your
              personal data by contacting us.
            </p>

            <h2>Contact</h2>
            <p>
              For privacy-related inquiries, contact us at{" "}
              <a href="mailto:hello@nichepulse.com">hello@nichepulse.com</a>.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
