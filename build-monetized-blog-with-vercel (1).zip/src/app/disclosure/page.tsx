import Header from "@/components/Header";
import Footer from "@/components/Footer";

export const metadata = {
  title: "Affiliate Disclosure — NichePulse",
  description: "Our affiliate disclosure and transparency policy.",
};

export default function DisclosurePage() {
  return (
    <>
      <Header />
      <main className="min-h-screen">
        <div className="max-w-3xl mx-auto px-4 py-16">
          <h1 className="text-4xl font-extrabold text-gray-900 mb-8">
            Affiliate Disclosure
          </h1>
          <div className="prose max-w-none">
            <p>
              <strong>Last updated:</strong> January 2025
            </p>

            <h2>Transparency is Our Priority</h2>
            <p>
              NichePulse is committed to transparency. We believe you should know
              how we make money and how it might influence the content on our
              site.
            </p>

            <h2>What Are Affiliate Links?</h2>
            <p>
              Some of the links on NichePulse are &quot;affiliate links.&quot;
              This means if you click on the link and purchase the item, we will
              receive an affiliate commission. This comes at absolutely no extra
              cost to you — the price you pay is the same whether you use our
              link or go directly to the vendor&apos;s website.
            </p>

            <h2>Our Promise</h2>
            <p>
              We only recommend products and services that we have personally
              researched, tested, or thoroughly evaluated. Our affiliate
              partnerships do not influence our editorial content. If we
              don&apos;t believe a product is worth your money, we won&apos;t
              recommend it — regardless of any potential commission.
            </p>

            <h2>How We Select Products</h2>
            <p>
              Our editorial team independently selects products to review based
              on:
            </p>
            <ul>
              <li>Reader demand and search trends</li>
              <li>Our personal experience with the product category</li>
              <li>Quality and value for money</li>
              <li>Reputation and reliability of the brand</li>
            </ul>

            <h2>Sponsored Content</h2>
            <p>
              Occasionally, brands pay us to create content about their products
              or services. All sponsored content is clearly labeled with a
              &quot;Sponsored&quot; badge. Even in sponsored posts, we maintain
              our honest editorial voice and will not make claims we don&apos;t
              believe to be true.
            </p>

            <h2>Advertising</h2>
            <p>
              We display third-party advertisements on our site. These ads are
              managed by ad networks and are separate from our editorial content.
              We do our best to ensure ads are relevant and non-intrusive.
            </p>

            <h2>Amazon Associates</h2>
            <p>
              NichePulse is a participant in the Amazon Services LLC Associates
              Program, an affiliate advertising program designed to provide a
              means for sites to earn advertising fees by advertising and linking
              to Amazon.com.
            </p>

            <h2>Questions?</h2>
            <p>
              If you have any questions about our affiliate relationships or
              advertising practices, please contact us at{" "}
              <a href="mailto:hello@nichepulse.com">hello@nichepulse.com</a>.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
