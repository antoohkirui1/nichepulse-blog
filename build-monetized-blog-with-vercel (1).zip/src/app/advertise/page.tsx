import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Link from "next/link";

export const metadata = {
  title: "Advertise With Us — NichePulse",
  description:
    "Reach 50,000+ engaged readers. Explore advertising opportunities with NichePulse.",
};

export default function AdvertisePage() {
  return (
    <>
      <Header />
      <main className="min-h-screen">
        <section className="bg-gradient-to-br from-gray-900 to-primary-950 text-white py-16 md:py-24">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-extrabold mb-6">
              Advertise With NichePulse
            </h1>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              Reach a highly engaged audience of tech-savvy consumers and
              decision-makers. Our readers trust our recommendations.
            </p>
          </div>
        </section>

        {/* Stats */}
        <section className="max-w-4xl mx-auto px-4 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { stat: "50K+", label: "Monthly Visitors" },
              { stat: "3.2%", label: "Click-Through Rate" },
              { stat: "45K+", label: "Newsletter Subs" },
              { stat: "4:30", label: "Avg. Time on Page" },
            ].map((item) => (
              <div
                key={item.label}
                className="bg-white border border-gray-200 rounded-xl p-5"
              >
                <div className="text-2xl font-extrabold text-primary-600">
                  {item.stat}
                </div>
                <div className="text-sm text-gray-600 mt-1">{item.label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Ad options */}
        <section className="bg-gray-50 py-16">
          <div className="max-w-4xl mx-auto px-4">
            <h2 className="text-3xl font-extrabold text-gray-900 text-center mb-12">
              Advertising Options
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  title: "Display Ads",
                  price: "From $500/mo",
                  icon: "📢",
                  features: [
                    "Header banner (728x90)",
                    "Sidebar ads (300x250)",
                    "In-article placements",
                    "Footer banners",
                  ],
                },
                {
                  title: "Sponsored Posts",
                  price: "From $1,500",
                  icon: "✍️",
                  features: [
                    "Professional content creation",
                    "SEO-optimized article",
                    "Social media promotion",
                    "Newsletter feature",
                  ],
                },
                {
                  title: "Affiliate Partnership",
                  price: "Revenue Share",
                  icon: "🤝",
                  features: [
                    "Dedicated product reviews",
                    "Deal page placement",
                    "Comparison articles",
                    "Email campaigns",
                  ],
                },
              ].map((option) => (
                <div
                  key={option.title}
                  className="bg-white rounded-2xl border border-gray-200 p-8 text-center hover:shadow-lg transition-shadow"
                >
                  <span className="text-4xl block mb-3">{option.icon}</span>
                  <h3 className="text-xl font-bold text-gray-900 mb-1">
                    {option.title}
                  </h3>
                  <p className="text-primary-600 font-bold mb-4">
                    {option.price}
                  </p>
                  <ul className="text-sm text-gray-600 space-y-2 mb-6">
                    {option.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 justify-center">
                        <span className="text-green-500">✓</span> {f}
                      </li>
                    ))}
                  </ul>
                  <Link
                    href="/contact"
                    className="inline-block px-6 py-2.5 bg-primary-600 text-white font-semibold text-sm rounded-lg hover:bg-primary-700 transition"
                  >
                    Get Started
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="max-w-4xl mx-auto px-4 py-16 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-3">
            Ready to Reach Our Audience?
          </h2>
          <p className="text-gray-600 mb-6">
            Contact our advertising team to discuss custom partnerships.
          </p>
          <Link
            href="/contact"
            className="inline-block px-8 py-3.5 bg-primary-600 text-white font-bold rounded-xl hover:bg-primary-700 transition"
          >
            Contact Us →
          </Link>
        </section>
      </main>
      <Footer />
    </>
  );
}
