import Header from "@/components/Header";
import Footer from "@/components/Footer";
import NewsletterSignup from "@/components/NewsletterSignup";
import Link from "next/link";

export const metadata = {
  title: "About Us — NichePulse",
  description:
    "Learn about NichePulse, our mission, and the team behind the reviews.",
};

export default function AboutPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen">
        {/* Hero */}
        <section className="bg-gradient-to-br from-primary-50 to-accent-50 py-16 md:py-24">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 mb-6">
              About NichePulse
            </h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed">
              We&apos;re a team of researchers, writers, and product enthusiasts
              dedicated to helping you make smarter buying decisions through
              honest, in-depth reviews and guides.
            </p>
          </div>
        </section>

        {/* Mission */}
        <section className="max-w-4xl mx-auto px-4 py-16">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-extrabold text-gray-900 mb-4">
                Our Mission
              </h2>
              <p className="text-gray-600 leading-relaxed mb-4">
                In a world full of sponsored content and fake reviews, we believe
                in transparency and honesty. Every product we recommend has been
                thoroughly researched and tested by our team.
              </p>
              <p className="text-gray-600 leading-relaxed">
                We earn revenue through affiliate partnerships and advertising,
                but this never influences our recommendations. If a product
                isn&apos;t worth your money, we&apos;ll tell you — regardless
                of any potential commission.
              </p>
            </div>
            <div className="bg-gradient-to-br from-primary-100 to-accent-100 rounded-2xl p-8 text-center">
              <span className="text-6xl block mb-4">🎯</span>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Our Promise
              </h3>
              <p className="text-gray-600 text-sm">
                Every review is honest, every recommendation is earned, and
                every reader is valued.
              </p>
            </div>
          </div>
        </section>

        {/* How We Make Money */}
        <section className="bg-gray-50 py-16">
          <div className="max-w-4xl mx-auto px-4">
            <h2 className="text-3xl font-extrabold text-gray-900 text-center mb-12">
              How We Make Money
            </h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white rounded-xl p-6 border border-gray-200 text-center">
                <span className="text-4xl block mb-3">📝</span>
                <h3 className="font-bold text-gray-900 mb-2">Affiliate Links</h3>
                <p className="text-sm text-gray-600">
                  We earn commissions when you purchase through our links.
                  This never adds to your cost — the merchant pays us from
                  their margin.
                </p>
              </div>
              <div className="bg-white rounded-xl p-6 border border-gray-200 text-center">
                <span className="text-4xl block mb-3">📢</span>
                <h3 className="font-bold text-gray-900 mb-2">
                  Display Advertising
                </h3>
                <p className="text-sm text-gray-600">
                  We show ads from relevant advertisers throughout our site.
                  We carefully vet all advertisers for quality and relevance.
                </p>
              </div>
              <div className="bg-white rounded-xl p-6 border border-gray-200 text-center">
                <span className="text-4xl block mb-3">🤝</span>
                <h3 className="font-bold text-gray-900 mb-2">
                  Sponsored Content
                </h3>
                <p className="text-sm text-gray-600">
                  Occasionally, brands sponsor articles. These are always
                  clearly labeled, and our editorial opinions remain
                  independent.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Team */}
        <section className="max-w-4xl mx-auto px-4 py-16">
          <h2 className="text-3xl font-extrabold text-gray-900 text-center mb-12">
            Meet the Team
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Alex Chen",
                role: "Founder & Editor-in-Chief",
                bio: "10+ years in tech journalism. Previously at TechCrunch and Wired.",
              },
              {
                name: "Sarah Mitchell",
                role: "Reviews Editor",
                bio: "Product testing specialist with a background in consumer electronics.",
              },
              {
                name: "Marcus Johnson",
                role: "Content Strategist",
                bio: "Digital marketing expert passionate about helping creators succeed.",
              },
            ].map((member) => (
              <div
                key={member.name}
                className="bg-white rounded-xl border border-gray-200 p-6 text-center"
              >
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary-400 to-accent-400 mx-auto mb-4" />
                <h3 className="font-bold text-gray-900">{member.name}</h3>
                <p className="text-xs text-primary-600 font-semibold mb-2">
                  {member.role}
                </p>
                <p className="text-sm text-gray-600">{member.bio}</p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="max-w-xl mx-auto px-4 pb-16">
          <NewsletterSignup variant="banner" />
        </section>
      </main>
      <Footer />
    </>
  );
}
