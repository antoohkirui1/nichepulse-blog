import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AffiliateProductCard from "@/components/AffiliateProductCard";
import AdBanner from "@/components/AdBanner";
import NewsletterSignup from "@/components/NewsletterSignup";
import { db } from "@/db";
import { affiliateLinks } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Deals & Coupons — NichePulse",
  description:
    "Exclusive deals, discounts, and coupons on products we recommend. Save money with our curated deals.",
};

export default async function DealsPage() {
  const deals = await db
    .select()
    .from(affiliateLinks)
    .where(eq(affiliateLinks.isActive, true))
    .orderBy(desc(affiliateLinks.clicks));

  const categories = [...new Set(deals.map((d) => d.category).filter(Boolean))];

  return (
    <>
      <Header />
      <main className="min-h-screen">
        {/* Hero */}
        <section className="bg-gradient-to-br from-warm-400 to-warm-600 text-white py-16">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <span className="text-5xl mb-4 block">🏷️</span>
            <h1 className="text-4xl md:text-5xl font-extrabold mb-3">
              Deals & Coupons
            </h1>
            <p className="text-lg text-white/90 max-w-2xl mx-auto">
              Exclusive discounts and offers on products we&apos;ve tested and
              recommend. Updated regularly.
            </p>
          </div>
        </section>

        <AdBanner position="header" label="Featured Deal" />

        {/* Deals grid */}
        <section className="max-w-4xl mx-auto px-4 py-12">
          {categories.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-8">
              {categories.map((cat) => (
                <span
                  key={cat}
                  className="px-4 py-2 bg-warm-100 text-warm-800 rounded-full text-sm font-medium"
                >
                  {cat}
                </span>
              ))}
            </div>
          )}

          {deals.length === 0 ? (
            <div className="text-center py-20">
              <span className="text-5xl mb-4 block">🔍</span>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                No active deals right now
              </h3>
              <p className="text-gray-500">
                Subscribe to our newsletter to get notified when new deals go
                live.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {deals.map((deal) => (
                <AffiliateProductCard
                  key={deal.id}
                  name={deal.name}
                  url={deal.url}
                  merchant={deal.merchant}
                  description={deal.description}
                  commission={deal.commission}
                />
              ))}
            </div>
          )}

          <div className="mt-12 text-center">
            <p className="text-xs text-gray-400">
              * Affiliate links — we may earn a commission at no extra cost to
              you.
            </p>
          </div>
        </section>

        <NewsletterSignup variant="banner" />
      </main>
      <Footer />
    </>
  );
}
