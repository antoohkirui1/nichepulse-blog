import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PostCard from "@/components/PostCard";
import AdBanner from "@/components/AdBanner";
import NewsletterSignup from "@/components/NewsletterSignup";
import { db } from "@/db";
import { posts, categories } from "@/db/schema";
import { eq, desc, or, ilike, sql } from "drizzle-orm";
import Link from "next/link";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Blog — NichePulse | Reviews, Guides & Deals",
  description:
    "Browse all our latest articles, reviews, guides, and deal roundups.",
};

async function getBlogData(searchParams: {
  [key: string]: string | string[] | undefined;
}) {
  const page = Number(searchParams.page) || 1;
  const category = searchParams.category as string | undefined;
  const search = searchParams.search as string | undefined;
  const limit = 9;
  const offset = (page - 1) * limit;

  const conditions = [eq(posts.status, "published")];

  if (category) {
    const cat = await db
      .select({ id: categories.id })
      .from(categories)
      .where(eq(categories.slug, category))
      .limit(1);
    if (cat.length > 0) {
      conditions.push(eq(posts.categoryId, cat[0].id));
    }
  }

  if (search) {
    conditions.push(
      or(
        ilike(posts.title, `%${search}%`),
        ilike(posts.excerpt, `%${search}%`)
      )!
    );
  }

  const whereClause =
    conditions.length === 1
      ? conditions[0]
      : sql`${conditions[0]} AND ${conditions.slice(1).reduce((a, b) => sql`${a} AND ${b}`)}`;

  const [postsList, totalResult, cats] = await Promise.all([
    db
      .select()
      .from(posts)
      .where(whereClause)
      .orderBy(desc(posts.publishedAt))
      .limit(limit)
      .offset(offset),
    db
      .select({ count: sql<number>`count(*)::int` })
      .from(posts)
      .where(whereClause),
    db.select().from(categories),
  ]);

  const catMap = new Map(cats.map((c) => [c.id, c]));
  const total = totalResult[0]?.count || 0;

  return {
    posts: postsList,
    categories: cats,
    catMap,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    },
  };
}

export default async function BlogPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const params = await searchParams;
  const data = await getBlogData(params);

  return (
    <>
      <Header />
      <main className="min-h-screen">
        {/* Page Header */}
        <section className="bg-gradient-to-br from-primary-50 to-accent-50 py-12 md:py-16">
          <div className="max-w-7xl mx-auto px-4">
            <h1 className="text-3xl md:text-5xl font-extrabold text-gray-900 mb-3">
              Our Blog
            </h1>
            <p className="text-lg text-gray-600 max-w-2xl">
              Expert reviews, in-depth guides, and the best deals — all in one
              place.
            </p>
          </div>
        </section>

        {/* Category filters */}
        <div className="max-w-7xl mx-auto px-4 py-6 border-b border-gray-100">
          <div className="flex flex-wrap gap-2">
            <Link
              href="/blog"
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                !params.category
                  ? "bg-primary-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              All Posts
            </Link>
            {data.categories.map((cat) => (
              <Link
                key={cat.id}
                href={`/blog?category=${cat.slug}`}
                className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                  params.category === cat.slug
                    ? "bg-primary-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {cat.name}
              </Link>
            ))}
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 py-10">
          <div className="flex flex-col lg:flex-row gap-10">
            {/* Main content */}
            <div className="flex-1">
              {data.posts.length === 0 ? (
                <div className="text-center py-20">
                  <span className="text-5xl mb-4 block">📭</span>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    No posts found
                  </h3>
                  <p className="text-gray-500">
                    Try a different category or check back later.
                  </p>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {data.posts.map((post) => (
                    <PostCard
                      key={post.id}
                      post={post}
                      categoryName={
                        post.categoryId
                          ? data.catMap.get(post.categoryId)?.name
                          : undefined
                      }
                      categorySlug={
                        post.categoryId
                          ? data.catMap.get(post.categoryId)?.slug
                          : undefined
                      }
                    />
                  ))}
                </div>
              )}

              {/* Pagination */}
              {data.pagination.totalPages > 1 && (
                <div className="flex justify-center gap-2 mt-10">
                  {Array.from(
                    { length: data.pagination.totalPages },
                    (_, i) => i + 1
                  ).map((p) => (
                    <Link
                      key={p}
                      href={`/blog?page=${p}${params.category ? `&category=${params.category}` : ""}`}
                      className={`w-10 h-10 flex items-center justify-center rounded-lg text-sm font-medium transition ${
                        p === data.pagination.page
                          ? "bg-primary-600 text-white"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                    >
                      {p}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            {/* Sidebar */}
            <aside className="w-full lg:w-80 flex-shrink-0 space-y-6">
              {/* Search */}
              <div className="bg-white border border-gray-200 rounded-xl p-5">
                <h3 className="font-bold text-gray-900 mb-3">Search</h3>
                <form action="/blog" method="GET">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      name="search"
                      defaultValue={(params.search as string) || ""}
                      placeholder="Search articles..."
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700 transition"
                    >
                      Go
                    </button>
                  </div>
                </form>
              </div>

              {/* Newsletter */}
              <NewsletterSignup variant="card" />

              {/* Sidebar Ad */}
              <AdBanner position="sidebar" label="Sponsored content" />

              {/* Popular categories */}
              <div className="bg-white border border-gray-200 rounded-xl p-5">
                <h3 className="font-bold text-gray-900 mb-3">Categories</h3>
                <div className="space-y-2">
                  {data.categories.map((cat) => (
                    <Link
                      key={cat.id}
                      href={`/category/${cat.slug}`}
                      className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-gray-50 transition"
                    >
                      <span className="text-sm text-gray-700">{cat.name}</span>
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: cat.color || "#3b82f6" }}
                      />
                    </Link>
                  ))}
                </div>
              </div>
            </aside>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
