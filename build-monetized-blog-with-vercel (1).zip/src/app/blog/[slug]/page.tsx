import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AdBanner from "@/components/AdBanner";
import SponsoredBadge from "@/components/SponsoredBadge";
import AffiliateProductCard from "@/components/AffiliateProductCard";
import NewsletterSignup from "@/components/NewsletterSignup";
import PostCard from "@/components/PostCard";
import { db } from "@/db";
import {
  posts,
  categories,
  tags,
  postTags,
  affiliateLinks,
  postAffiliateLinks,
} from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { format } from "date-fns";
import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";

async function getPost(slug: string) {
  const post = await db
    .select()
    .from(posts)
    .where(eq(posts.slug, slug))
    .limit(1);

  if (post.length === 0) return null;

  const postData = post[0];

  // Increment view count
  await db
    .update(posts)
    .set({ views: sql`${posts.views} + 1` })
    .where(eq(posts.id, postData.id));

  // Get category
  let category = null;
  if (postData.categoryId) {
    const cat = await db
      .select()
      .from(categories)
      .where(eq(categories.id, postData.categoryId))
      .limit(1);
    category = cat[0] || null;
  }

  // Get tags
  const postTagList = await db
    .select({ id: tags.id, name: tags.name, slug: tags.slug })
    .from(postTags)
    .innerJoin(tags, eq(postTags.tagId, tags.id))
    .where(eq(postTags.postId, postData.id));

  // Get affiliate links
  const postAffiliates = await db
    .select({
      id: affiliateLinks.id,
      name: affiliateLinks.name,
      url: affiliateLinks.url,
      merchant: affiliateLinks.merchant,
      description: affiliateLinks.description,
      commission: affiliateLinks.commission,
      anchorText: postAffiliateLinks.anchorText,
    })
    .from(postAffiliateLinks)
    .innerJoin(
      affiliateLinks,
      eq(postAffiliateLinks.affiliateLinkId, affiliateLinks.id)
    )
    .where(eq(postAffiliateLinks.postId, postData.id));

  // Related posts
  const relatedPosts = postData.categoryId
    ? await db
        .select()
        .from(posts)
        .where(
          sql`${posts.categoryId} = ${postData.categoryId} AND ${posts.id} != ${postData.id} AND ${posts.status} = 'published'`
        )
        .limit(3)
    : [];

  return {
    post: { ...postData, views: postData.views + 1 },
    category,
    tags: postTagList,
    affiliateLinks: postAffiliates,
    relatedPosts,
  };
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = await db
    .select({
      title: posts.title,
      excerpt: posts.excerpt,
      metaTitle: posts.metaTitle,
      metaDescription: posts.metaDescription,
    })
    .from(posts)
    .where(eq(posts.slug, slug))
    .limit(1);

  if (post.length === 0) return { title: "Post Not Found" };

  return {
    title: post[0].metaTitle || `${post[0].title} — NichePulse`,
    description: post[0].metaDescription || post[0].excerpt || "",
  };
}

export default async function BlogPostPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const data = await getPost(slug);

  if (!data) notFound();

  const { post, category, tags: postTagsList, affiliateLinks: affLinks, relatedPosts } = data;
  const publishDate = post.publishedAt
    ? format(new Date(post.publishedAt), "MMMM d, yyyy")
    : "";

  return (
    <>
      <Header />
      <main className="min-h-screen">
        {/* Article Header */}
        <section className="bg-gradient-to-br from-gray-50 to-primary-50/30 py-10 md:py-16">
          <div className="max-w-4xl mx-auto px-4">
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 text-sm text-gray-500 mb-6">
              <Link href="/" className="hover:text-primary-600 transition">
                Home
              </Link>
              <span>/</span>
              <Link href="/blog" className="hover:text-primary-600 transition">
                Blog
              </Link>
              {category && (
                <>
                  <span>/</span>
                  <Link
                    href={`/category/${category.slug}`}
                    className="hover:text-primary-600 transition"
                  >
                    {category.name}
                  </Link>
                </>
              )}
            </nav>

            {/* Category + Sponsored badge */}
            <div className="flex flex-wrap items-center gap-3 mb-4">
              {category && (
                  <Link
                    href={`/category/${category.slug}`}
                    className="text-xs font-semibold uppercase tracking-wider px-3 py-1 rounded-full"
                    style={{
                      backgroundColor: `${category.color || "#3b82f6"}20`,
                      color: category.color || "#3b82f6",
                    }}
                  >
                  {category.name}
                </Link>
              )}
              {post.isSponsored && (
                <span className="sponsored-badge text-xs font-bold text-white px-3 py-1 rounded-full">
                  Sponsored
                </span>
              )}
            </div>

            <h1 className="text-3xl md:text-5xl font-extrabold text-gray-900 leading-tight mb-6">
              {post.title}
            </h1>

            {post.excerpt && (
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                {post.excerpt}
              </p>
            )}

            {/* Author & Meta */}
            <div className="flex flex-wrap items-center gap-6 text-sm text-gray-500">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary-400 to-accent-400" />
                <div>
                  <div className="font-semibold text-gray-900">
                    {post.authorName || "Editorial Team"}
                  </div>
                  <div className="text-xs text-gray-500">Author</div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
                <span>{publishDate}</span>
              </div>
              <div className="flex items-center gap-1">
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                  />
                </svg>
                <span>{post.views.toLocaleString()} views</span>
              </div>
            </div>

            {/* Tags */}
            {postTagsList.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-6">
                {postTagsList.map((tag) => (
                  <span
                    key={tag.id}
                    className="bg-white border border-gray-200 text-gray-600 text-xs font-medium px-3 py-1 rounded-full"
                  >
                    #{tag.name}
                  </span>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Sponsored Badge */}
        {post.isSponsored && (
          <div className="max-w-4xl mx-auto px-4">
            <SponsoredBadge
              sponsorName={post.sponsorName}
              sponsorUrl={post.sponsorUrl}
              sponsorLogo={post.sponsorLogo}
            />
          </div>
        )}

        {/* Article Content */}
        <div className="max-w-4xl mx-auto px-4 py-10">
          <div className="flex flex-col lg:flex-row gap-10">
            {/* Main content */}
            <article className="flex-1 min-w-0">
              {/* In-article ad */}
              {affLinks.length > 0 && (
                <AdBanner
                  position="in-article"
                  label="Sponsored recommendation"
                />
              )}

              {/* Article body */}
              <div
                className="prose max-w-none"
                dangerouslySetInnerHTML={{ __html: post.content }}
              />

              {/* Affiliate links section */}
              {affLinks.length > 0 && (
                <div className="mt-10 pt-8 border-t border-gray-200">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    🛒 Recommended Products
                  </h3>
                  <p className="text-sm text-gray-500 mb-4">
                    We may earn a commission from qualifying purchases. This
                    helps support our work at no extra cost to you.
                  </p>
                  {affLinks.map((aff) => (
                    <AffiliateProductCard
                      key={aff.id}
                      name={aff.name}
                      url={aff.url}
                      merchant={aff.merchant}
                      description={aff.description}
                      commission={aff.commission}
                    />
                  ))}
                </div>
              )}

              {/* Share buttons */}
              <div className="mt-10 pt-8 border-t border-gray-200">
                <h3 className="text-lg font-bold text-gray-900 mb-4">
                  Share this article
                </h3>
                <div className="flex gap-3">
                  <a
                    href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(post.title)}&url=${encodeURIComponent(typeof window !== "undefined" ? window.location.href : "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-gray-800 transition"
                  >
                    Twitter
                  </a>
                  <a
                    href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(typeof window !== "undefined" ? window.location.href : "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition"
                  >
                    Facebook
                  </a>
                  <a
                    href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(typeof window !== "undefined" ? window.location.href : "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-blue-800 text-white text-sm font-medium rounded-lg hover:bg-blue-900 transition"
                  >
                    LinkedIn
                  </a>
                </div>
              </div>

              {/* Author box */}
              <div className="mt-10 bg-gray-50 rounded-2xl p-6 flex gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary-400 to-accent-400 flex-shrink-0" />
                <div>
                  <h4 className="font-bold text-gray-900">
                    {post.authorName || "Editorial Team"}
                  </h4>
                  <p className="text-sm text-gray-600 mt-1">
                    Expert reviewer and content creator at NichePulse. Passionate
                    about helping readers make informed purchasing decisions
                    through honest, in-depth reviews.
                  </p>
                </div>
              </div>
            </article>

            {/* Sidebar */}
            <aside className="w-full lg:w-80 flex-shrink-0">
              <div className="lg:sticky lg:top-24 space-y-6">
                {/* Newsletter */}
                <NewsletterSignup variant="card" />

                {/* Sidebar ad */}
                <AdBanner position="sidebar" label="Sponsored" />

                {/* Affiliate disclosure */}
                <div className="bg-warm-50 border border-warm-200 rounded-xl p-4">
                  <h4 className="font-bold text-warm-800 text-sm mb-2">
                    💡 Affiliate Disclosure
                  </h4>
                  <p className="text-xs text-warm-700 leading-relaxed">
                    Some links in this article are affiliate links. We may earn a
                    commission if you make a purchase through our links, at no
                    additional cost to you. This helps us keep creating free
                    content.
                  </p>
                </div>
              </div>
            </aside>
          </div>
        </div>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <section className="bg-gray-50 py-16">
            <div className="max-w-7xl mx-auto px-4">
              <h2 className="text-2xl font-extrabold text-gray-900 mb-8 text-center">
                Related Articles
              </h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {relatedPosts.map((rp) => (
                  <PostCard
                    key={rp.id}
                    post={rp}
                    categoryName={category?.name}
                    categorySlug={category?.slug}
                  />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Footer Ad */}
        <div className="max-w-7xl mx-auto px-4 py-6">
          <AdBanner position="footer" label="Start your own blog today" />
        </div>
      </main>
      <Footer />
    </>
  );
}
