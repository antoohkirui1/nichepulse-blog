import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { affiliateLinks } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function POST(request: NextRequest) {
  try {
    const { id } = await request.json();

    if (!id) {
      return NextResponse.json({ error: "Missing link ID" }, { status: 400 });
    }

    // Increment click count
    await db
      .update(affiliateLinks)
      .set({ clicks: sql`${affiliateLinks.clicks} + 1` })
      .where(eq(affiliateLinks.id, id));

    // Get the URL to redirect
    const link = await db
      .select({ url: affiliateLinks.url })
      .from(affiliateLinks)
      .where(eq(affiliateLinks.id, id))
      .limit(1);

    if (link.length === 0) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 });
    }

    return NextResponse.json({ url: link[0].url });
  } catch (error) {
    console.error("Affiliate click error:", error);
    return NextResponse.json(
      { error: "Something went wrong" },
      { status: 500 }
    );
  }
}
