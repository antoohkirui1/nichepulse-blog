import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { posts, categories } from "@/db/schema";
import { eq, and, or, ilike, desc, sql } from "drizzle-orm";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const q = searchParams.get("q") || "";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = 10;
    const offset = (page - 1) * limit;

    if (!q || q.length < 2) {
      return NextResponse.json({ posts: [], total: 0 });
    }

    const where = and(
      eq(posts.status, "published"),
      or(
        ilike(posts.title, `%${q}%`),
        ilike(posts.excerpt, `%${q}%`),
        ilike(posts.content, `%${q}%`)
      )!
    );

    const [results, countResult] = await Promise.all([
      db
        .select({
          id: posts.id,
          title: posts.title,
          slug: posts.slug,
          excerpt: posts.excerpt,
          publishedAt: posts.publishedAt,
          categoryId: posts.categoryId,
        })
        .from(posts)
        .where(where)
        .orderBy(desc(posts.publishedAt))
        .limit(limit)
        .offset(offset),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(posts)
        .where(where),
    ]);

    return NextResponse.json({
      posts: results,
      total: countResult[0]?.count || 0,
    });
  } catch (error) {
    console.error("Search error:", error);
    return NextResponse.json(
      { error: "Search failed" },
      { status: 500 }
    );
  }
}
