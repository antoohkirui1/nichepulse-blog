import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  posts,
  categories,
  tags,
  postTags,
  affiliateLinks,
  postAffiliateLinks,
} from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;

    const post = await db
      .select()
      .from(posts)
      .where(eq(posts.slug, slug))
      .limit(1);

    if (post.length === 0) {
      return NextResponse.json({ error: "Post not found" }, { status: 404 });
    }

    const postData = post[0];

    // Increment view count
    await db
      .update(posts)
      .set({ views: sql`${posts.views} + 1` })
      .where(eq(posts.id, postData.id));

    // Get category
    let category = null;
    if (postData.categoryId) {
      const cat = await db
        .select()
        .from(categories)
        .where(eq(categories.id, postData.categoryId))
        .limit(1);
      category = cat[0] || null;
    }

    // Get tags
    const postTagList = await db
      .select({
        id: tags.id,
        name: tags.name,
        slug: tags.slug,
      })
      .from(postTags)
      .innerJoin(tags, eq(postTags.tagId, tags.id))
      .where(eq(postTags.postId, postData.id));

    // Get affiliate links for this post
    const postAffiliates = await db
      .select({
        id: affiliateLinks.id,
        name: affiliateLinks.name,
        url: affiliateLinks.url,
        merchant: affiliateLinks.merchant,
        description: affiliateLinks.description,
        commission: affiliateLinks.commission,
        anchorText: postAffiliateLinks.anchorText,
      })
      .from(postAffiliateLinks)
      .innerJoin(
        affiliateLinks,
        eq(postAffiliateLinks.affiliateLinkId, affiliateLinks.id)
      )
      .where(eq(postAffiliateLinks.postId, postData.id));

    // Get related posts (same category, different post)
    const relatedPosts = postData.categoryId
      ? await db
          .select({
            id: posts.id,
            title: posts.title,
            slug: posts.slug,
            excerpt: posts.excerpt,
            coverImage: posts.coverImage,
            publishedAt: posts.publishedAt,
            isSponsored: posts.isSponsored,
            authorName: posts.authorName,
            views: posts.views,
          })
          .from(posts)
          .where(
            sql`${posts.categoryId} = ${postData.categoryId} AND ${posts.id} != ${postData.id} AND ${posts.status} = 'published'`
          )
          .limit(3)
      : [];

    return NextResponse.json({
      post: {
        ...postData,
        views: postData.views + 1,
      },
      category,
      tags: postTagList,
      affiliateLinks: postAffiliates,
      relatedPosts,
    });
  } catch (error) {
    console.error("Post fetch error:", error);
    return NextResponse.json(
      { error: "Failed to fetch post" },
      { status: 500 }
    );
  }
}
