import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { posts, categories, tags, postTags } from "@/db/schema";
import { eq, and, desc, sql, ilike, or } from "drizzle-orm";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "12");
    const category = searchParams.get("category");
    const featured = searchParams.get("featured");
    const search = searchParams.get("search");
    const offset = (page - 1) * limit;

    const conditions = [eq(posts.status, "published")];

    if (category) {
      const cat = await db
        .select({ id: categories.id })
        .from(categories)
        .where(eq(categories.slug, category))
        .limit(1);
      if (cat.length > 0) {
        conditions.push(eq(posts.categoryId, cat[0].id));
      }
    }

    if (featured === "true") {
      conditions.push(eq(posts.isFeatured, true));
    }

    if (search) {
      conditions.push(
        or(
          ilike(posts.title, `%${search}%`),
          ilike(posts.excerpt, `%${search}%`)
        )!
      );
    }

    const whereClause = and(...conditions);

    const [postsList, totalResult] = await Promise.all([
      db
        .select({
          id: posts.id,
          title: posts.title,
          slug: posts.slug,
          excerpt: posts.excerpt,
          coverImage: posts.coverImage,
          authorName: posts.authorName,
          isSponsored: posts.isSponsored,
          sponsorName: posts.sponsorName,
          publishedAt: posts.publishedAt,
          views: posts.views,
          categoryId: posts.categoryId,
          isFeatured: posts.isFeatured,
        })
        .from(posts)
        .where(whereClause)
        .orderBy(desc(posts.publishedAt))
        .limit(limit)
        .offset(offset),
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(posts)
        .where(whereClause),
    ]);

    // Fetch categories for these posts
    const categoryIds = [
      ...new Set(postsList.map((p) => p.categoryId).filter(Boolean)),
    ];
    const cats =
      categoryIds.length > 0
        ? await db
            .select()
            .from(categories)
            .where(
              or(...categoryIds.map((id) => eq(categories.id, id!)))!
            )
        : [];

    const catMap = new Map(cats.map((c) => [c.id, c]));

    const enrichedPosts = postsList.map((post) => ({
      ...post,
      category: post.categoryId ? catMap.get(post.categoryId) : null,
    }));

    const total = totalResult[0]?.count || 0;

    return NextResponse.json({
      posts: enrichedPosts,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error("Posts fetch error:", error);
    return NextResponse.json(
      { error: "Failed to fetch posts" },
      { status: 500 }
    );
  }
}
