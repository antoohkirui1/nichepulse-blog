import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  categories,
  tags,
  posts,
  postTags,
  affiliateLinks,
  postAffiliateLinks,
  adPlacements,
} from "@/db/schema";

export async function POST() {
  try {
    // ── Categories ───────────────────────────────────────────────────────
    const categoryData = [
      {
        name: "Reviews",
        slug: "reviews",
        description: "In-depth product and service reviews",
        color: "#3b82f6",
      },
      {
        name: "Guides",
        slug: "guides",
        description: "Step-by-step tutorials and how-to guides",
        color: "#10b981",
      },
      {
        name: "Deals",
        slug: "deals",
        description: "Best deals, discounts, and coupons",
        color: "#f59e0b",
      },
      {
        name: "Tech",
        slug: "tech",
        description: "Technology news and insights",
        color: "#8b5cf6",
      },
      {
        name: "Finance",
        slug: "finance",
        description: "Personal finance tips and tools",
        color: "#ef4444",
      },
    ];
    const insertedCategories = await db
      .insert(categories)
      .values(categoryData)
      .returning();

    // ── Tags ─────────────────────────────────────────────────────────────
    const tagData = [
      { name: "Best Of", slug: "best-of" },
      { name: "Budget", slug: "budget" },
      { name: "Premium", slug: "premium" },
      { name: "Beginner", slug: "beginner" },
      { name: "Advanced", slug: "advanced" },
      { name: "2025", slug: "2025" },
      { name: "Comparison", slug: "comparison" },
      { name: "Tutorial", slug: "tutorial" },
      { name: "Savings", slug: "savings" },
      { name: "Tools", slug: "tools" },
    ];
    const insertedTags = await db.insert(tags).values(tagData).returning();

    // ── Posts ────────────────────────────────────────────────────────────
    const postData = [
      {
        title: "The Ultimate Guide to Building Your First Website in 2025",
        slug: "ultimate-guide-building-first-website-2025",
        excerpt:
          "Everything you need to know about creating a professional website from scratch, including hosting, design, and launch strategies.",
        content: `<h2>Why You Need a Website in 2025</h2>
<p>Having your own website is no longer optional — it's essential. Whether you're a freelancer, small business owner, or content creator, a professional website establishes credibility and opens up new opportunities.</p>

<h2>Step 1: Choose Your Platform</h2>
<p>The first decision you'll make is which platform to use. Here are the top options:</p>
<ul>
<li><strong>WordPress</strong> — Most flexible, powers 40%+ of the web</li>
<li><strong>Next.js</strong> — Best for developers who want full control</li>
<li><strong>Webflow</strong> — Visual design without code</li>
<li><strong>Shopify</strong> — Best for e-commerce stores</li>
</ul>

<h2>Step 2: Select a Hosting Provider</h2>
<p>Your hosting provider determines your site's speed, reliability, and scalability. We recommend starting with a managed hosting solution that handles the technical details for you.</p>

<blockquote>A fast website isn't just nice to have — it directly impacts your search engine rankings and conversion rates.</blockquote>

<h2>Step 3: Design & Content</h2>
<p>Focus on clean design, fast loading times, and valuable content. Your homepage should immediately communicate what you offer and why visitors should care.</p>

<h2>Step 4: Launch & Optimize</h2>
<p>Once live, set up analytics, submit your sitemap to search engines, and start creating regular content to build organic traffic.</p>`,
        authorName: "Alex Chen",
        categoryId: insertedCategories[1].id, // Guides
        status: "published",
        isFeatured: true,
        views: 12847,
        publishedAt: new Date("2025-01-15"),
      },
      {
        title: "Top 10 Web Hosting Services Compared (2025 Review)",
        slug: "top-10-web-hosting-services-2025-review",
        excerpt:
          "We tested 30+ hosting providers over 6 months. Here are the ones that actually deliver on speed, uptime, and support.",
        content: `<h2>How We Tested</h2>
<p>We set up identical test sites on 30+ hosting providers and monitored them for 6 months. We measured uptime, speed, support response time, and value for money.</p>

<h2>Our Top Picks</h2>
<h3>1. Cloudways — Best Overall</h3>
<p>Cloudways offers managed cloud hosting with incredible performance. Their platform lets you choose between DigitalOcean, Vultr, AWS, and Google Cloud servers.</p>

<h3>2. SiteGround — Best for Beginners</h3>
<p>With their intuitive dashboard and excellent support, SiteGround is perfect for those just starting out.</p>

<h3>3. WPX Hosting — Best for WordPress</h3>
<p>If you're running WordPress, WPX delivers blazing-fast speeds with their custom CDN and optimized servers.</p>

<h2>Performance Comparison</h2>
<p>Speed matters. Our tests showed that the top providers delivered sub-200ms response times, while budget options averaged 800ms+. That's a 4x difference that directly affects your visitors' experience.</p>

<blockquote>Investing in quality hosting pays for itself through better SEO rankings and higher conversion rates.</blockquote>

<h2>Final Verdict</h2>
<p>For most users, we recommend starting with Cloudways or SiteGround. Both offer excellent performance at reasonable prices, with room to grow as your site scales.</p>`,
        authorName: "Sarah Mitchell",
        categoryId: insertedCategories[0].id, // Reviews
        status: "published",
        isFeatured: true,
        isSponsored: true,
        sponsorName: "Cloudways",
        sponsorUrl: "https://cloudways.com",
        views: 28453,
        publishedAt: new Date("2025-02-01"),
      },
      {
        title: "How to Start a Profitable Blog: A Complete Roadmap",
        slug: "how-to-start-profitable-blog-complete-roadmap",
        excerpt:
          "Follow this step-by-step roadmap to launch a blog that generates real income through ads, affiliates, and digital products.",
        content: `<h2>The Blog Business Model</h2>
<p>Blogging isn't just a hobby anymore — it's a legitimate business model. Top bloggers earn $10,000-$100,000+ per month through a combination of advertising, affiliate marketing, and their own products.</p>

<h2>Phase 1: Foundation (Month 1-2)</h2>
<p>Choose a profitable niche, set up your blog, and create your first 10 cornerstone articles. Focus on topics with high search volume and commercial intent.</p>

<h2>Phase 2: Growth (Month 3-6)</h2>
<p>Publish consistently (2-3 posts per week), build your email list, and start implementing basic SEO strategies. This is when you'll start seeing organic traffic grow.</p>

<h2>Phase 3: Monetization (Month 6-12)</h2>
<p>Once you have steady traffic, it's time to monetize:</p>
<ul>
<li><strong>Display Ads</strong> — Start with Google AdSense, graduate to Mediavine or AdThrive</li>
<li><strong>Affiliate Marketing</strong> — Promote products you genuinely recommend</li>
<li><strong>Sponsored Posts</strong> — Partner with brands in your niche</li>
<li><strong>Digital Products</strong> — Create courses, ebooks, or templates</li>
</ul>

<h2>Phase 4: Scale (Year 2+)</h2>
<p>Hire writers, expand into new content formats (video, podcasting), and diversify your income streams. The key is building systems that allow growth without burning out.</p>`,
        authorName: "Marcus Johnson",
        categoryId: insertedCategories[1].id, // Guides
        status: "published",
        isFeatured: false,
        views: 9821,
        publishedAt: new Date("2025-02-10"),
      },
      {
        title: "7 Best Email Marketing Tools for Small Business (Tested)",
        slug: "best-email-marketing-tools-small-business-2025",
        excerpt:
          "We sent 50,000+ emails across 7 platforms to find the best email marketing tool for small businesses and bloggers.",
        content: `<h2>Why Email Marketing Still Matters</h2>
<p>Despite the rise of social media, email marketing delivers the highest ROI of any marketing channel — $42 for every $1 spent on average.</p>

<h2>Our Testing Process</h2>
<p>We created identical email campaigns and sent them to segmented lists across 7 platforms. We measured deliverability, open rates, click-through rates, and ease of use.</p>

<h2>The Results</h2>
<h3>1. ConvertKit — Best for Creators</h3>
<p>Built specifically for bloggers and creators, ConvertKit offers powerful automation with an intuitive interface.</p>

<h3>2. Mailchimp — Best for Beginners</h3>
<p>The most recognized name in email marketing, Mailchimp offers a generous free plan and easy-to-use templates.</p>

<h3>3. ActiveCampaign — Best for Advanced Users</h3>
<p>If you need sophisticated automation and CRM features, ActiveCampaign is the most powerful option available.</p>

<h2>Pricing Comparison</h2>
<p>For a list of 1,000 subscribers, expect to pay between $0 (free tiers) and $29/month. The key is finding the tool that matches your current needs while offering room to grow.</p>`,
        authorName: "Lisa Park",
        categoryId: insertedCategories[0].id, // Reviews
        status: "published",
        isFeatured: false,
        isSponsored: true,
        sponsorName: "ConvertKit",
        sponsorUrl: "https://convertkit.com",
        views: 15632,
        publishedAt: new Date("2025-02-15"),
      },
      {
        title:
          "Passive Income with Digital Products: The Complete Playbook",
        slug: "passive-income-digital-products-complete-playbook",
        excerpt:
          "Learn how to create and sell digital products that generate revenue while you sleep. Real examples and strategies inside.",
        content: `<h2>The Digital Product Revolution</h2>
<p>Digital products offer the ultimate business model: create once, sell forever. No inventory, no shipping, and nearly infinite margins.</p>

<h2>Types of Digital Products</h2>
<ul>
<li><strong>Online Courses</strong> — Teach what you know ($50-$500+ per sale)</li>
<li><strong>Ebooks & Guides</strong> — Package your expertise ($10-$50)</li>
<li><strong>Templates</strong> — Save people time ($15-$100)</li>
<li><strong>Software & Tools</strong> — Solve specific problems (subscription pricing)</li>
<li><strong>Membership Sites</strong> — Recurring revenue ($10-$100/month)</li>
</ul>

<h2>Finding Your Product Idea</h2>
<p>The best digital products solve a specific problem for a specific audience. Look for:</p>
<ul>
<li>Questions people repeatedly ask you</li>
<li>Topics you can explain better than existing resources</li>
<li>Gaps in the market for your niche</li>
</ul>

<h2>Launch Strategy</h2>
<p>Don't just create and hope. Build anticipation with a pre-launch sequence: tease content, collect emails, offer early-bird pricing, and leverage social proof.</p>`,
        authorName: "Alex Chen",
        categoryId: insertedCategories[4].id, // Finance
        status: "published",
        isFeatured: false,
        views: 7234,
        publishedAt: new Date("2025-03-01"),
      },
      {
        title: "Best Budget Laptops for Students in 2025",
        slug: "best-budget-laptops-students-2025",
        excerpt:
          "We reviewed 15 laptops under $600 to find the best options for students. Performance, battery life, and value — all tested.",
        content: `<h2>What Students Need in a Laptop</h2>
<p>A great student laptop needs to balance performance, portability, battery life, and price. After testing 15 models, here are our top picks.</p>

<h2>Top Picks</h2>
<h3>1. Acer Aspire 5 — Best Value ($449)</h3>
<p>Outstanding performance for the price with a comfortable keyboard and all-day battery life.</p>

<h3>2. Lenovo IdeaPad 3 — Best Budget ($379)</h3>
<p>If you're on a tight budget, the IdeaPad 3 delivers reliable performance for basic tasks.</p>

<h3>3. MacBook Air M1 — Best Overall ($799 refurbished)</h3>
<p>While slightly above our budget threshold when new, refurbished M1 MacBook Airs offer unbeatable performance and battery life.</p>

<h2>What to Look For</h2>
<ul>
<li>At least 8GB RAM (16GB preferred)</li>
<li>SSD storage (256GB minimum)</li>
<li>Full HD display</li>
<li>8+ hours battery life</li>
<li>Comfortable keyboard for long study sessions</li>
</ul>`,
        authorName: "Sarah Mitchell",
        categoryId: insertedCategories[3].id, // Tech
        status: "published",
        isFeatured: false,
        views: 22190,
        publishedAt: new Date("2025-03-05"),
      },
      {
        title: "50% Off Premium VPN — Limited Time Deal",
        slug: "50-percent-off-premium-vpn-limited-time-deal",
        excerpt:
          "Get 50% off a top-rated VPN service. Protect your privacy online with military-grade encryption at half the price.",
        content: `<h2>Why You Need a VPN in 2025</h2>
<p>With increasing cyber threats and privacy concerns, a VPN is no longer optional. It encrypts your internet connection, hides your IP address, and lets you access content from anywhere.</p>

<h2>The Deal</h2>
<p>For a limited time, you can get our top-rated VPN at 50% off the regular price. This deal includes:</p>
<ul>
<li>Unlimited bandwidth</li>
<li>Servers in 90+ countries</li>
<li>No-log policy (verified by independent audits)</li>
<li>24/7 customer support</li>
<li>30-day money-back guarantee</li>
</ul>

<blockquote>This is the lowest price we've seen all year. The deal expires at the end of the month.</blockquote>

<h2>How to Claim</h2>
<p>Click the link below to activate the discount. The 50% off will be applied automatically at checkout.</p>`,
        authorName: "Editorial Team",
        categoryId: insertedCategories[2].id, // Deals
        status: "published",
        isFeatured: false,
        views: 5432,
        publishedAt: new Date("2025-03-10"),
      },
    ];

    const insertedPosts = await db
      .insert(posts)
      .values(postData)
      .returning();

    // ── Post Tags ────────────────────────────────────────────────────────
    const postTagData = [
      { postId: insertedPosts[0].id, tagId: insertedTags[3].id }, // Beginner
      { postId: insertedPosts[0].id, tagId: insertedTags[7].id }, // Tutorial
      { postId: insertedPosts[1].id, tagId: insertedTags[0].id }, // Best Of
      { postId: insertedPosts[1].id, tagId: insertedTags[6].id }, // Comparison
      { postId: insertedPosts[1].id, tagId: insertedTags[5].id }, // 2025
      { postId: insertedPosts[2].id, tagId: insertedTags[3].id }, // Beginner
      { postId: insertedPosts[2].id, tagId: insertedTags[7].id }, // Tutorial
      { postId: insertedPosts[3].id, tagId: insertedTags[0].id }, // Best Of
      { postId: insertedPosts[3].id, tagId: insertedTags[9].id }, // Tools
      { postId: insertedPosts[4].id, tagId: insertedTags[4].id }, // Advanced
      { postId: insertedPosts[5].id, tagId: insertedTags[0].id }, // Best Of
      { postId: insertedPosts[5].id, tagId: insertedTags[1].id }, // Budget
      { postId: insertedPosts[6].id, tagId: insertedTags[8].id }, // Savings
      { postId: insertedPosts[6].id, tagId: insertedTags[5].id }, // 2025
    ];
    await db.insert(postTags).values(postTagData);

    // ── Affiliate Links ──────────────────────────────────────────────────
    const affiliateData = [
      {
        name: "Cloudways Managed Hosting",
        url: "https://cloudways.com/?ref=nichepulse",
        merchant: "Cloudways",
        description: "Managed cloud hosting with 3-day free trial",
        category: "Hosting",
        commission: "Up to $125 per referral",
        isActive: true,
      },
      {
        name: "ConvertKit Email Marketing",
        url: "https://convertkit.com/?ref=nichepulse",
        merchant: "ConvertKit",
        description: "Email marketing for creators — free up to 1,000 subs",
        category: "Email Marketing",
        commission: "30% recurring commission",
        isActive: true,
      },
      {
        name: "ExpressVPN",
        url: "https://expressvpn.com/?ref=nichepulse",
        merchant: "ExpressVPN",
        description: "Premium VPN with 50% off for annual plans",
        category: "VPN",
        commission: "$13-$36 per sale",
        isActive: true,
      },
      {
        name: "Astra WordPress Theme",
        url: "https://wpastra.com/?ref=nichepulse",
        merchant: "Brainstorm Force",
        description: "Fastest WordPress theme — works with all page builders",
        category: "WordPress",
        commission: "30% per sale",
        isActive: true,
      },
      {
        name: "Amazon Associates — Tech Products",
        url: "https://amazon.com/?tag=nichepulse-20",
        merchant: "Amazon",
        description: "Shop our recommended tech products on Amazon",
        category: "Marketplace",
        commission: "1-10% per sale",
        isActive: true,
      },
    ];
    const insertedAffiliates = await db
      .insert(affiliateLinks)
      .values(affiliateData)
      .returning();

    // ── Post ↔ Affiliate Links ───────────────────────────────────────────
    await db.insert(postAffiliateLinks).values([
      {
        postId: insertedPosts[0].id,
        affiliateLinkId: insertedAffiliates[3].id,
        anchorText: "Astra WordPress Theme",
      },
      {
        postId: insertedPosts[1].id,
        affiliateLinkId: insertedAffiliates[0].id,
        anchorText: "Cloudways Hosting",
      },
      {
        postId: insertedPosts[3].id,
        affiliateLinkId: insertedAffiliates[1].id,
        anchorText: "ConvertKit",
      },
      {
        postId: insertedPosts[6].id,
        affiliateLinkId: insertedAffiliates[2].id,
        anchorText: "ExpressVPN",
      },
      {
        postId: insertedPosts[5].id,
        affiliateLinkId: insertedAffiliates[4].id,
        anchorText: "Amazon",
      },
    ]);

    // ── Ad Placements ────────────────────────────────────────────────────
    await db.insert(adPlacements).values([
      {
        name: "Header Banner",
        position: "header",
        adCode:
          '<div style="background:linear-gradient(135deg,#3b82f6,#8b5cf6);color:white;padding:16px;text-align:center;border-radius:8px;"><strong>🎯 Special Offer:</strong> Get 50% off premium hosting — <a href="#" style="color:#fbbf24;text-decoration:underline;">Claim Deal</a></div>',
        isActive: true,
      },
      {
        name: "Sidebar Newsletter",
        position: "sidebar",
        adCode: "newsletter-widget",
        isActive: true,
      },
      {
        name: "In-Article Affiliate",
        position: "in-article",
        adCode: "affiliate-widget",
        isActive: true,
      },
      {
        name: "Footer Banner",
        position: "footer",
        adCode:
          '<div style="background:#1e293b;color:white;padding:20px;text-align:center;border-radius:8px;"><strong>Start Your Blog Today</strong><br/>Everything you need to launch and grow — <a href="#" style="color:#60a5fa;">Get Started Free</a></div>',
        isActive: true,
      },
    ]);

    return NextResponse.json({
      message: "Database seeded successfully!",
      counts: {
        categories: insertedCategories.length,
        tags: insertedTags.length,
        posts: insertedPosts.length,
        affiliateLinks: insertedAffiliates.length,
      },
    });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json(
      { error: "Failed to seed database", details: String(error) },
      { status: 500 }
    );
  }
}
