import { NextResponse } from "next/server";

const ADSENSE_ID =
  process.env.NEXT_PUBLIC_ADSENSE_ID || "ca-pub-6993130926858430";

export async function GET() {
  const content = `google.com, ${ADSENSE_ID}, DIRECT, f08c47fec0942fa0
`;

  return new NextResponse(content, {
    headers: {
      "Content-Type": "text/plain",
      "Cache-Control": "public, max-age=3600",
    },
  });
}
