import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PostCard from "@/components/PostCard";
import AdBanner from "@/components/AdBanner";
import NewsletterSignup from "@/components/NewsletterSignup";
import { db } from "@/db";
import { posts, categories } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";

async function getCategoryData(slug: string) {
  const cat = await db
    .select()
    .from(categories)
    .where(eq(categories.slug, slug))
    .limit(1);

  if (cat.length === 0) return null;

  const category = cat[0];

  const [postsList, totalResult, allCats] = await Promise.all([
    db
      .select()
      .from(posts)
      .where(
        sql`${posts.categoryId} = ${category.id} AND ${posts.status} = 'published'`
      )
      .orderBy(desc(posts.publishedAt))
      .limit(12),
    db
      .select({ count: sql<number>`count(*)::int` })
      .from(posts)
      .where(
        sql`${posts.categoryId} = ${category.id} AND ${posts.status} = 'published'`
      ),
    db.select().from(categories),
  ]);

  return {
    category,
    posts: postsList,
    total: totalResult[0]?.count || 0,
    allCategories: allCats,
  };
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const cat = await db
    .select()
    .from(categories)
    .where(eq(categories.slug, slug))
    .limit(1);

  if (cat.length === 0) return { title: "Category Not Found" };

  return {
    title: `${cat[0].name} — NichePulse`,
    description: cat[0].description || `Browse all ${cat[0].name} articles.`,
  };
}

export default async function CategoryPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const data = await getCategoryData(slug);

  if (!data) notFound();

  return (
    <>
      <Header />
      <main className="min-h-screen">
        {/* Category Header */}
        <section
          className="py-12 md:py-16 text-white"
          style={{
            background: `linear-gradient(135deg, ${data.category.color || "#3b82f6"}, ${data.category.color || "#3b82f6"}dd)`,
          }}
        >
          <div className="max-w-7xl mx-auto px-4">
            <Link
              href="/blog"
              className="inline-flex items-center gap-1 text-white/80 hover:text-white text-sm mb-4 transition"
            >
              ← Back to Blog
            </Link>
            <h1 className="text-3xl md:text-5xl font-extrabold mb-3">
              {data.category.name}
            </h1>
            {data.category.description && (
              <p className="text-lg text-white/80 max-w-2xl">
                {data.category.description}
              </p>
            )}
            <p className="text-sm text-white/60 mt-3">
              {data.total} article{data.total !== 1 ? "s" : ""}
            </p>
          </div>
        </section>

        {/* Other categories */}
        <div className="max-w-7xl mx-auto px-4 py-6 border-b border-gray-100">
          <div className="flex flex-wrap gap-2">
            {data.allCategories.map((cat) => (
              <Link
                key={cat.id}
                href={`/category/${cat.slug}`}
                className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                  cat.id === data.category.id
                    ? "text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
                style={
                  cat.id === data.category.id
                    ? { backgroundColor: cat.color || "#3b82f6" }
                    : undefined
                }
              >
                {cat.name}
              </Link>
            ))}
          </div>
        </div>

        {/* Posts grid */}
        <div className="max-w-7xl mx-auto px-4 py-10">
          {data.posts.length === 0 ? (
            <div className="text-center py-20">
              <span className="text-5xl mb-4 block">📭</span>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                No posts yet
              </h3>
              <p className="text-gray-500">
                Check back soon for new {data.category.name.toLowerCase()}{" "}
                content.
              </p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {data.posts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  categoryName={data.category.name}
                  categorySlug={data.category.slug}
                />
              ))}
            </div>
          )}

          {/* Sidebar content */}
          <div className="mt-12 grid md:grid-cols-2 gap-8">
            <NewsletterSignup variant="banner" />
            <AdBanner position="footer" label="Sponsored: Featured product" />
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
