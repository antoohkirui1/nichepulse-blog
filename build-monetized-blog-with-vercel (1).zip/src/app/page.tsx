import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PostCard from "@/components/PostCard";
import AdBanner from "@/components/AdBanner";
import NewsletterSignup from "@/components/NewsletterSignup";
import AffiliateProductCard from "@/components/AffiliateProductCard";
import { db } from "@/db";
import { posts, categories, affiliateLinks } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";
import Link from "next/link";

export const dynamic = "force-dynamic";

async function getHomeData() {
  const [featuredPosts, latestPosts, cats, topAffiliates, stats] =
    await Promise.all([
      db
        .select()
        .from(posts)
        .where(eq(posts.status, "published"))
        .orderBy(desc(posts.publishedAt))
        .limit(2),
      db
        .select()
        .from(posts)
        .where(eq(posts.status, "published"))
        .orderBy(desc(posts.publishedAt))
        .limit(6),
      db.select().from(categories),
      db
        .select()
        .from(affiliateLinks)
        .where(eq(affiliateLinks.isActive, true))
        .limit(3),
      db
        .select({
          totalPosts: sql<number>`count(*)::int`,
          totalViews: sql<number>`coalesce(sum(${posts.views}), 0)::int`,
        })
        .from(posts)
        .where(eq(posts.status, "published")),
    ]);

  const catMap = new Map(cats.map((c) => [c.id, c]));

  return {
    featuredPosts,
    latestPosts: latestPosts.slice(2),
    categories: cats,
    topAffiliates,
    stats: stats[0],
    catMap,
  };
}

export default async function HomePage() {
  const data = await getHomeData();

  return (
    <>
      <Header />

      <main>
        {/* ── Hero Section ─────────────────────────────────────────────── */}
        <section className="relative overflow-hidden bg-gradient-to-br from-gray-900 via-primary-950 to-gray-900 text-white">
          <div className="absolute inset-0 opacity-10">
            <div
              className="absolute inset-0"
              style={{
                backgroundImage:
                  "radial-gradient(circle at 25% 25%, #3b82f6 0%, transparent 50%), radial-gradient(circle at 75% 75%, #d946ef 0%, transparent 50%)",
              }}
            />
          </div>
          <div className="relative max-w-7xl mx-auto px-4 py-16 md:py-24">
            <div className="max-w-3xl">
              <div className="inline-block bg-primary-600/30 border border-primary-500/40 text-primary-300 text-xs font-semibold px-4 py-1.5 rounded-full mb-6">
                🔥 Trusted by {data.stats.totalViews.toLocaleString()}+
                readers
              </div>
              <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-6">
                Expert Reviews.{" "}
                <span className="bg-gradient-to-r from-primary-400 to-accent-400 bg-clip-text text-transparent">
                  Honest Guides.
                </span>{" "}
                Best Deals.
              </h1>
              <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl leading-relaxed">
                We research, test, and review products so you don&apos;t have to.
                Make smarter buying decisions with our in-depth analysis and
                curated recommendations.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/blog"
                  className="px-8 py-3.5 bg-white text-gray-900 font-bold rounded-xl hover:bg-gray-100 transition text-center"
                >
                  Browse All Posts →
                </Link>
                <Link
                  href="/deals"
                  className="px-8 py-3.5 bg-transparent border-2 border-white/30 text-white font-bold rounded-xl hover:bg-white/10 transition text-center"
                >
                  🏷️ See Today&apos;s Deals
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* ── Ad Banner ────────────────────────────────────────────────── */}
        <div className="max-w-7xl mx-auto px-4 -mt-4 relative z-10">
          <AdBanner position="header" label="Sponsored: Premium Hosting Deal" />
        </div>

        {/* ── Featured Posts ───────────────────────────────────────────── */}
        <section className="max-w-7xl mx-auto px-4 py-12">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-gray-900">
                Featured Posts
              </h2>
              <p className="text-gray-500 mt-1">
                Our editors&apos; top picks this month
              </p>
            </div>
            <Link
              href="/blog"
              className="text-primary-600 hover:text-primary-700 font-semibold text-sm"
            >
              View all →
            </Link>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            {data.featuredPosts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                categoryName={
                  post.categoryId
                    ? data.catMap.get(post.categoryId)?.name
                    : undefined
                }
                categorySlug={
                  post.categoryId
                    ? data.catMap.get(post.categoryId)?.slug
                    : undefined
                }
                variant="featured"
              />
            ))}
          </div>
        </section>

        {/* ── Latest Posts Grid ────────────────────────────────────────── */}
        <section className="max-w-7xl mx-auto px-4 py-12">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-extrabold text-gray-900">
                Latest Articles
              </h2>
              <p className="text-gray-500 mt-1">
                Fresh content published this week
              </p>
            </div>
            <Link
              href="/blog"
              className="text-primary-600 hover:text-primary-700 font-semibold text-sm"
            >
              See all →
            </Link>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {data.latestPosts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                categoryName={
                  post.categoryId
                    ? data.catMap.get(post.categoryId)?.name
                    : undefined
                }
                categorySlug={
                  post.categoryId
                    ? data.catMap.get(post.categoryId)?.slug
                    : undefined
                }
              />
            ))}
          </div>
        </section>

        {/* ── Categories Grid ─────────────────────────────────────────── */}
        <section className="bg-gray-50 py-16">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl md:text-3xl font-extrabold text-gray-900 text-center mb-3">
              Explore by Category
            </h2>
            <p className="text-gray-500 text-center mb-10">
              Find exactly what you&apos;re looking for
            </p>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {data.categories.map((cat) => (
                <Link
                  key={cat.id}
                  href={`/category/${cat.slug}`}
                  className="bg-white rounded-xl p-5 text-center border border-gray-200 hover:border-primary-300 hover:shadow-lg transition-all group"
                >
                  <div
                    className="w-12 h-12 rounded-xl mx-auto mb-3 flex items-center justify-center text-white text-xl font-bold"
                    style={{ backgroundColor: cat.color || "#3b82f6" }}
                  >
                    {cat.name.charAt(0)}
                  </div>
                  <h3 className="font-bold text-gray-900 group-hover:text-primary-600 transition-colors">
                    {cat.name}
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">
                    {cat.description}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* ── Affiliate Products / Deals Section ───────────────────────── */}
        <section className="max-w-7xl mx-auto px-4 py-16">
          <div className="text-center mb-10">
            <span className="inline-block bg-warm-100 text-warm-700 text-xs font-bold px-4 py-1.5 rounded-full mb-3">
              🏷️ Top Deals
            </span>
            <h2 className="text-2xl md:text-3xl font-extrabold text-gray-900">
              Recommended Products & Deals
            </h2>
            <p className="text-gray-500 mt-2">
              Hand-picked products we use and recommend
            </p>
          </div>
          <div className="max-w-3xl mx-auto">
            {data.topAffiliates.map((aff) => (
              <AffiliateProductCard
                key={aff.id}
                name={aff.name}
                url={aff.url}
                merchant={aff.merchant}
                description={aff.description}
                commission={aff.commission}
              />
            ))}
          </div>
          <p className="text-center text-xs text-gray-400 mt-6">
            * Affiliate links — we may earn a commission at no extra cost to
            you.{" "}
            <Link href="/disclosure" className="underline hover:text-gray-600">
              Full disclosure
            </Link>
          </p>
        </section>

        {/* ── In-Article Ad ───────────────────────────────────────────── */}
        <div className="max-w-7xl mx-auto px-4">
          <AdBanner
            position="in-article"
            label="Sponsored: Start your blog today"
          />
        </div>

        {/* ── Newsletter Section ───────────────────────────────────────── */}
        <section className="max-w-7xl mx-auto px-4 py-16">
          <div className="max-w-xl mx-auto">
            <NewsletterSignup variant="banner" />
          </div>
        </section>

        {/* ── Stats Bar ───────────────────────────────────────────────── */}
        <section className="bg-gray-900 text-white py-12">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-3xl font-extrabold text-primary-400">
                  {data.stats.totalPosts}+
                </div>
                <div className="text-sm text-gray-400 mt-1">
                  Published Articles
                </div>
              </div>
              <div>
                <div className="text-3xl font-extrabold text-primary-400">
                  {data.stats.totalViews.toLocaleString()}+
                </div>
                <div className="text-sm text-gray-400 mt-1">Total Views</div>
              </div>
              <div>
                <div className="text-3xl font-extrabold text-primary-400">
                  50K+
                </div>
                <div className="text-sm text-gray-400 mt-1">
                  Newsletter Subscribers
                </div>
              </div>
              <div>
                <div className="text-3xl font-extrabold text-primary-400">
                  200+
                </div>
                <div className="text-sm text-gray-400 mt-1">
                  Affiliate Partners
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
}
