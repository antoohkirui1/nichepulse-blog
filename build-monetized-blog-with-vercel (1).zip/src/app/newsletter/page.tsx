import Header from "@/components/Header";
import Footer from "@/components/Footer";
import NewsletterSignup from "@/components/NewsletterSignup";

export const metadata = {
  title: "Newsletter — NichePulse",
  description:
    "Subscribe to the NichePulse newsletter. Get weekly reviews, guides, and exclusive deals.",
};

export default function NewsletterPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen">
        <section className="newsletter-cta py-20">
          <div className="max-w-3xl mx-auto px-4 text-center">
            <span className="text-6xl block mb-6">📬</span>
            <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4">
              The NichePulse Newsletter
            </h1>
            <p className="text-lg text-white/90 mb-8 max-w-xl mx-auto">
              Join 50,000+ readers who get our best content delivered straight
              to their inbox every week. No spam, just value.
            </p>
            <div className="max-w-md mx-auto">
              <NewsletterSignup variant="inline" />
            </div>
          </div>
        </section>

        <section className="max-w-3xl mx-auto px-4 py-16">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-10">
            What You&apos;ll Get
          </h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {[
              {
                icon: "📝",
                title: "Expert Reviews",
                desc: "In-depth product reviews you can trust, published weekly.",
              },
              {
                icon: "📊",
                title: "Comparison Guides",
                desc: "Side-by-side comparisons to help you choose the right product.",
              },
              {
                icon: "🏷️",
                title: "Exclusive Deals",
                desc: "Subscriber-only discounts and early access to sales.",
              },
              {
                icon: "💡",
                title: "Pro Tips",
                desc: "Insider knowledge and expert recommendations.",
              },
            ].map((item) => (
              <div
                key={item.title}
                className="bg-white border border-gray-200 rounded-xl p-6"
              >
                <span className="text-3xl block mb-3">{item.icon}</span>
                <h3 className="font-bold text-gray-900 mb-1">{item.title}</h3>
                <p className="text-sm text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
